#ifndef lab2_1
#define lab2_1

#include "Arduino.h"

#endif