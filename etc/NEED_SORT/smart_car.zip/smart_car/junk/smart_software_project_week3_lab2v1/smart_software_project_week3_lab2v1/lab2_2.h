#ifndef lab2_2
#define lab2_2

#include "Arduino.h"

#endif