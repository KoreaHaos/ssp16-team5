// Start of the header guard
#ifndef lab3
#define lab3

#include "Arduino.h"

void move_smart_car(int left_ms, int right_ms);
void move_stop();

// End of the header guard
#endif
