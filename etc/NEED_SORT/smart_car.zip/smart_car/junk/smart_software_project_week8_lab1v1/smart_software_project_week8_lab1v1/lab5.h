#ifndef lab5
#define lab5

#include "Arduino.h"

#endif