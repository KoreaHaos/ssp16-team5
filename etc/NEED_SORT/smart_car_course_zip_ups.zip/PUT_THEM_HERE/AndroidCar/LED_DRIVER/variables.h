#ifndef led_vars_h
#define led_vars_h

enum State {
  RIGHT,
  STOP,
  MOVING_STRAIGHT,
  LEFT,
  RC
};

#define RX_PIN 2
#define UNUSED_TX_PIN 3

#endif
