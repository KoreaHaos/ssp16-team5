/* Placeholder for an ultrasonic sensor class */

#include "Smartcar.h"

UltrasonicSensor::UltrasonicSensor(){
	_sensorMedianDelay = 0; //the default median delay for the ultrasonic sensors will be redefined in child classes if necessary
}
