#ifndef smart_car_sensors
#define smart_car_sensors

void setup_ultrasonic();

void ultrasonic_sensor_read();
#endif