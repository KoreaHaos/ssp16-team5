#include "a_haos_smartcar_project.h"

void setup() {
	
	setup_buzzer_pin();
	setup_led_pins();
	start_smartcar_control_logic();
	startup_movement();
	setup_ultrasonic();
	
}
void loop() {
    
}
