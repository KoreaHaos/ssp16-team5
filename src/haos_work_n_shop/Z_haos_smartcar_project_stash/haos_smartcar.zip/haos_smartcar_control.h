#ifndef smart_car_control_logic
#define smart_car_control_logic

void setup_smart_car_control_logic();

#endif
