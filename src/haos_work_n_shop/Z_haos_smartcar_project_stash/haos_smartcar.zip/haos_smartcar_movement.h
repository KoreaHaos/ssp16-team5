#ifndef HAOS_MOVE_SMARTCAR_H
#define HAOS_MOVE_SMARTCAR_H

void startup_movement();

void move_car_analogue(int left_motor_speed, int right_motor_speed);

#endif